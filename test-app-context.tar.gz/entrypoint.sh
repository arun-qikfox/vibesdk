#!/usr/bin/env bash
set -euo pipefail

log() {
	printf '[cloudrun-entrypoint] %s\n' "$*" >&2
}

# Custom command override.
if [[ -n "${START_COMMAND:-}" ]]; then
	log "Executing START_COMMAND override"
	exec bash -lc "$START_COMMAND"
fi

# Prefer explicit start script when available.
if [[ -f package.json ]]; then
	if npm run | grep -qE '(^| )start( |$)'; then
		log "Detected npm start script; launching application"
		exec npm run start
	fi
fi

# Fallback: static dist directory.
if [[ -d dist ]]; then
	log "No start script found; serving ./dist with serve@14"
	exec serve -s dist -l "${PORT:-8080}"
fi

log "No start script or dist directory found. Set START_COMMAND or provide a start script."
exec sleep infinity
